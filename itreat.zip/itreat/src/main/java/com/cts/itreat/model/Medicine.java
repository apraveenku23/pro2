package com.cts.itreat.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="medicine")
public class Medicine {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long medid;
	@Column(nullable=false)
	private String name;
	@Column(nullable=false)
	private String quantity;

	public Long getMedid() {
		return medid;
	}
	public void setMedid(Long medid) {
		this.medid = medid;
	}
	public String getMedName() {
		return name;
	}
	public void setMedName(String medName) {
		this.name = medName;
	}
	public String getMedTime() {
		return quantity;
	}
	public void setMedTime(String medTime) {
		this.quantity = medTime;
	}
	@Override
	public String toString() {
		return "Medicine [medid=" + medid + ", medName=" + name + ", medTime=" + quantity + "]";
	}
	public Medicine(String medName, String medTime) {
		super();
		this.name = medName;
		this.quantity = medTime;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Medicine other = (Medicine) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	public Medicine() {
		
	}
	
	
}
