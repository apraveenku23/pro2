package com.cts.itreat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItreatApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItreatApplication.class, args);
	}

}
