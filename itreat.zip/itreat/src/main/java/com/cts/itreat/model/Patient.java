package com.cts.itreat.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Patient")
public class Patient {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable =false)
	private Long pid;
	@Column(nullable = false)
	private String pfname;// should be unique
	@Column(nullable = false)
	private String plname;
	@Column(nullable = false)
	private String address;
	@Column(nullable = false)	
	private int contactNo;

	@OneToMany(targetEntity = QandA.class,cascade = CascadeType.ALL)
	@JoinColumn(name="qna_fk", referencedColumnName = "pid")
	private List<QandA> qandA;
	@OneToMany(targetEntity = Medicine.class,cascade = CascadeType.ALL)
	@JoinColumn(name="med_fk", referencedColumnName = "pid")
	private List<Medicine> medicine;
	@OneToMany(targetEntity = Schedule.class,cascade = CascadeType.ALL)
	@JoinColumn(name="schedule_fk", referencedColumnName = "pid")
	private List<Schedule> schedule;
	@OneToMany(targetEntity = OperationDetails.class,cascade = CascadeType.ALL)
	@JoinColumn(name="opDetails_fk", referencedColumnName = "pid")
	private List<OperationDetails> Opdetails;
	@OneToOne
	private Logins logins;
	
	public Long getPid() {
		return pid;
	}
	public void setPid(Long pid) {
		this.pid = pid;
	}
	public String getPfname() {
		return pfname;
	}
	public void setPfname(String pfname) {
		this.pfname = pfname;
	}
	public String getPlname() {
		return plname;
	}
	public void setPlname(String plname) {
		this.plname = plname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getContact() {
		return contactNo;
	}
	public void setContact(int contact) {
		this.contactNo = contact;
	}
	
	
	
	public List<QandA> getQandA() {
		return qandA;
	}
	public void setQandA(List<QandA> qandA) {
		this.qandA = qandA;
	}
	public List<Medicine> getMedicine() {
		return medicine;
	}
	public void setMedicine(List<Medicine> medicine) {
		this.medicine = medicine;
	}
	public List<Schedule> getSchedule() {
		return schedule;
	}
	public void setSchedule(List<Schedule> schedule) {
		this.schedule = schedule;
	}
	public List<OperationDetails> getOpdetails() {
		return Opdetails;
	}
	public void setOpdetails(List<OperationDetails> opdetails) {
		Opdetails = opdetails;
	}
	public Logins getLogins() {
		return logins;
	}
	public void setLogins(Logins logins) {
		this.logins = logins;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((pfname == null) ? 0 : pfname.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Patient other = (Patient) obj;
		if (pfname == null) {
			if (other.pfname != null)
				return false;
		} else if (!pfname.equals(other.pfname))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Patient [pid=" + pid + ", pfname=" + pfname + ", plname=" + plname + ", address=" + address
				+ ", contact=" + contactNo + ", qandA=" + qandA + ", medicine=" + medicine + ", schedule=" + schedule
				+ ", Opdetails=" + Opdetails + ", logins=" + logins + "]";
	}
	
	public Patient(String pfname, String plname, String address, int contact, List<QandA> qandA,
			List<Medicine> medicine, List<Schedule> schedule, List<OperationDetails> opdetails, Logins logins) {
		super();
		this.pfname = pfname;
		this.plname = plname;
		this.address = address;
		this.contactNo = contact;
		this.qandA = qandA;
		this.medicine = medicine;
		this.schedule = schedule;
		Opdetails = opdetails;
		this.logins = logins;
	}
	public Patient() {
		
	}
	
	
	
}
