package com.cts.itreat.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="qanda")
public class QandA {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long qid;
	@Column(nullable=false)
	private String Question;
	@Column(nullable=false)
	private String Answer;
//	@ManyToOne
//	private Patient patient;
	public Long getQid() {
		return qid;
	}
	public void setQid(Long qid) {
		this.qid = qid;
	}
	public String getQuestion() {
		return Question;
	}
	public void setQuestion(String question) {
		Question = question;
	}
	public String getAnswer() {
		return Answer;
	}
	public void setAnswer(String answer) {
		Answer = answer;
	}
	public QandA(String question, String answer) {
		super();
		Question = question;
		Answer = answer;
	}
	
	
}
