package com.cts.itreat.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Schedule")
public class Schedule {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Schedule_id;
	@Column(nullable = false)
	private String instruction;
	@Column(nullable = false)
	private String timing;
//	@ManyToOne
//	private Patient patient;
	public Long getSchedule_id() {
		return Schedule_id;
	}
	public void setSchedule_id(Long schedule_id) {
		Schedule_id = schedule_id;
	}
	public String getSchedule() {
		return instruction;
	}
	public void setSchedule(String schedule) {
		instruction = schedule;
	}
	public String getSchedule_time() {
		return timing;
	}
	public void setSchedule_time(String schedule_time) {
		timing = schedule_time;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Schedule other = (Schedule) obj;
		if (instruction == null) {
			if (other.instruction != null)
				return false;
		} else if (!instruction.equals(other.instruction))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Schedule [Schedule_id=" + Schedule_id + ", Schedule=" + instruction + ", Schedule_time=" + timing
				+ "]";
	}
	public Schedule(String schedule, String schedule_time) {
		super();
		instruction = schedule;
		timing = schedule_time;
	}
	public Schedule() {
		
	}
	
}
