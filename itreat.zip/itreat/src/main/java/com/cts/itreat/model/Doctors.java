package com.cts.itreat.model;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "Doctors")
public class Doctors {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long did;
	@Column(nullable = false)
	private String dfname;
	@Column(nullable = false)
	private String dlname;
	@Column(nullable = false)
	private Long contact;
	@Column(nullable = false)
	private String speciality;
	@OneToMany(targetEntity = Patient.class,cascade = CascadeType.ALL)
	@JoinColumn(name="p_fk", referencedColumnName = "did")
	private List<Patient> patients;
	@OneToOne
	private Logins logins;
	
//	@OneToOne
//    @MapsId
//    @JoinColumn(name = "id")
//    private Logins logins;
	public Long getId() {
		return did;
	}
	public void setId(Long id) {
		this.did = id;
	}
	public String getDfname() {
		return dfname;
	}
	public void setDfname(String dfname) {
		this.dfname = dfname;
	}
	public String getDlname() {
		return dlname;
	}
	public void setDlname(String dlname) {
		this.dlname = dlname;
	}
	public Long getContact() {
		return contact;
	}
	public void setContact(Long contact) {
		this.contact = contact;
	}
	public String getSpeciality() {
		return speciality;
	}
	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}
//	@OneToOne(cascade = CascadeType.ALL)
//	private Logins login;
	
	
	
	@Override
	public String toString() {
		return "Users [id=" + did + ", dfname=" + dfname + ", dlname=" + dlname + ", contact=" + contact
				+ ", speciality=" + speciality + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dfname == null) ? 0 : dfname.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Doctors other = (Doctors) obj;
		if (dfname == null) {
			if (other.dfname != null)
				return false;
		} else if (!dfname.equals(other.dfname))
			return false;
		return true;
	}
	public Doctors(Long id, String dfname, String dlname, Long contact, String speciality) {
		super();
		this.did = id;
		this.dfname = dfname;
		this.dlname = dlname;
		this.contact = contact;
		this.speciality = speciality;
	}
	
	public Doctors() {
		
	}
	
	
	
}
