package com.cts.itreat.model;

public enum status {
	SUCCESS,
	USER_ALREADY_EXIST,
	FAILURE,
	PATIENT_ALREADY_EXIST,
	PATIENT_NOT_EXISTS
}
