package com.cts.itreat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.itreat.model.QandA;

@Repository
public interface QandARepository extends JpaRepository<QandA, Long>{

}
