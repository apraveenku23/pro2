package com.cts.itreat.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="OperationDetails")
public class OperationDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Opdetails_id;
	@Column(nullable = false)
	private String nameOfOperation;
	@Column(nullable = false)
	private String dateOfOperation;
	@Column(nullable = false)
	private String remarksOfOperation;
	public Long getOpdetails_id() {
		return Opdetails_id;
	}
	public void setOpdetails_id(Long opdetails_id) {
		Opdetails_id = opdetails_id;
	}
	public String getOpName() {
		return nameOfOperation;
	}
	public void setOpName(String opName) {
		nameOfOperation = opName;
	}
	public String getOpDate() {
		return dateOfOperation;
	}
	public void setOpDate(String opDate) {
		dateOfOperation = opDate;
	}
	public String getOpRemarks() {
		return remarksOfOperation;
	}
	public void setOpRemarks(String opRemarks) {
		remarksOfOperation = opRemarks;
	}
	@Override
	public String toString() {
		return "OperationDetails [Opdetails_id=" + Opdetails_id + ", OpName=" + nameOfOperation + ", OpDate=" + dateOfOperation
				+ ", OpRemarks=" + remarksOfOperation + "]";
	}
	public OperationDetails(String opName, String opDate, String opRemarks) {
		super();
		nameOfOperation = opName;
		dateOfOperation = opDate;
		remarksOfOperation = opRemarks;
	}
	
	

}
