package com.cts.itreat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItreatApplicationTests{

	@Test
	void contextLoads() {
	}

}